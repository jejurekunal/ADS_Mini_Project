package VendingMachine;
import java.util.Scanner;
import java.util.*;
public class VendingMachine 
{
	 private Item[] items;
	    
	    // storeing the values of the different items in the menu.
	        public VendingMachine()
	        {
	        items = new Item[8];
	        items[0] =new Item ("Lays Chips", 20.0, 20);
	        items[1] =new Item ("Kurkure", 20.0, 20);
	        items[2] =new Item ("Doritos", 30.0, 20);
	        items[3] =new Item ("Red Bull", 100.0, 2);
	        items[4] =new Item ("Sprit", 40.0, 20);
	        items[5] =new Item ("Slice", 40.0, 20);
	        items[6] =new Item ("Thums Up", 40.0, 20);
	        items[7] =new Item ("Mineral Water", 20.0, 20);
	        }
	        // To display the menu in the begining of the operation.
	        public void displayInventory()
	        {
	        for (int i = 0; i < items.length; i++)
	            {
	            System.out.print(items[i].getName());			 
	            System.out.print(items[i].getQty());			
	            System.out.println();
	            }
	        }
	        // To dispense the Selected iten
	         public void dispenseItem(int itemCode) 
	    {
	        Scanner in = new Scanner(System.in);				// Get input from the user
	        if (items[itemCode].getQty() <= 0) 
	        {
	            System.out.println("Sorry, out of stock");                  // the product nust be out of Stock.
	        }
	        else
	        {
	            System.out.println("MRP: Rs. " + items[itemCode].getPrice());   //display the product price.
	            System.out.print("Enter money: ");                              // ask user to enter the price
	            double amt = in.nextDouble();
	            if (amt < items[itemCode].getPrice()) 
	            {
	                System.out.println("Insufficient money paid, can't dispense " +     // In case the user entered Insufficient amount
	                    items[itemCode].getName());
	                System.out.println("Refunding " + amt);
	            }
	            else
	            {
	                System.out.println("Dispensing Your Order of " + items[itemCode].getName());    // To get change after operation
	                double changeAmt = amt - items[itemCode].getPrice();
	                if (changeAmt > 0)
	                    System.out.println("Here is your change amount of Rs. " + changeAmt);
	                items[itemCode].reduceQty();
	            }
	        }
	    }
	        Item[] getItems()           // return to the menu function                                    
	        {
	        return items;
	        }
	         public static void main(String args[]) 
	        {

	        Scanner in = new Scanner(System.in);
	        VendingMachine vm = new VendingMachine();
	        Item[] vmItems = vm.getItems();
	        System.out.println("                          ");
	        System.out.println("Welcome to Vending Machine");
	        System.out.println("                          ");
	        System.out.println("****************************");
	        System.out.println("*** Vending Machine Menu ***");
	        System.out.println("****************************");
	        System.out.println("                          ");
	        for (int i = 0; i < vmItems.length; i++) 
	        {
	            System.out.println("Enter " + (i+1) + " for " + vmItems[i].getName());      // Select the Item
	           //System.out.println("Press "+(i+1)+" For "+ vmItems[i].getName());
	        }
	         System.out.println("Press 9 to stop the Vending Machine");             // Stoping Operation
	        
	        int choice;
	        do {                
	            choice = in.nextInt();                                              // User Selection part
	            
	            if (choice < 1 && choice > 8)                                       // if choice from 1 to 8
	            {
	                System.out.println("XX_Incorrect choice_XX");                   // Incorrect Choice
	            }
	            else if(choice == 9)                                                // Stoping...
	            {
	                System.out.println("******************************");
	                System.out.println("...Stopping Vending Machine...");
	                System.out.println("******************************");
	                System.out.println("...THANK-YOU FOR CHOOSING US...");
	                System.out.println("        HAVE A GOOD DAY        ");
	            }
	            else {
	                System.out.print("Enter Price: ");                              // Dispance and reduce 1 item every time from the Quantity
	                vm.dispenseItem(choice - 1);
	                
	            }
	        } 
	        while(choice != 9);
	    }    
}
