package VendingMachine;

public class Item {
	 private String name;
	    private double price;
	    private int quantity;
	    
	    public Item(String itemName, double itemPrice, int itemQty) {
	        name = itemName;
	        price = itemPrice;
	        quantity = itemQty;
	    }
	    
	    public String getName() 
	    {
	        return name;
	    }
	    
	    public double getPrice() 
	    {
	        return price;
	    }
	    
	    public int getQty() 
	    {
	        return quantity;
	    }
	     public void reduceQty() 
	    {
	        if (quantity > 0)
	        	quantity -= 1;
	    }
}
